use Dugma1


-- drop table mechirot
create table mechirot 
( 
siduri int primary key identity(1,1) ,
shem nvarchar(50),
ezor nvarchar(50),
yom nvarchar(50),
mechiraYomit int
)
;

insert into mechirot values
('malka', 'zafon', '1', 2000), 
('malka', 'zafon', '2', 1000), 
('malka', 'zafon', '3', 1000),
('malka', 'zafon', '4', 2000),
('malka', 'zafon', '5', 1000),

('liat', 'zafon', '1', 4000),
('liat', 'zafon', '2', 2000),
('liat', 'zafon', '3', 2000),
('liat', 'zafon', '4', 3000),
('liat', 'zafon', '5', 200),

('eden','merkaz', '1', 600),
('eden','merkaz', '2', 300),
('eden','merkaz', '3', 400),
('eden','merkaz', '4', 300),
('eden','merkaz', '5', 300),

('batya','merkaz', '5', 10000)

;
select * from mechirot

-- drop table rezerva
create table rezerva
( 
siduri int primary key identity(1,1) ,
shem nvarchar(50),
memuza int
)

insert into rezerva values
('rafi', 20),
('nofar', 1000),
('tal', 3000),
('amit', 5000);



-- PART 1 subqueries
select avg(mechiraYomit) from mechirot
-- we want to get the records above the average
-- select * from mechirot where mechiraYomit > avg(mechiraYomit)
-- ERROR!!!
-- SOLUTION: subquery
select * from mechirot where mechiraYomit >
	(select avg(mechiraYomit) from mechirot)

-- ��� ��� ����� ���� ���� ���� ���� ��� ��� �� ���
select * from mechirot where mechiraYomit <
	(select max(mechiraYomit) from mechirot where shem = 'eden')

-- ���� ���� �����? ��� �� �� ������� ������ ����� ����
-- �� ���� ����� ���...?
select shem from mechirot where ezor = 
	(select ezor from mechirot where shem = 'malka')    -- without distinct
	and shem != 'malka'
-- ERROR!!! Why?
-- tikun:

-- A: subquery only 1 result
select distinct shem from mechirot where ezor = 
	(select distinct ezor from mechirot where shem = 'malka')
	and shem != 'malka'

--B : take from subquery with 'in' and distinct on main query
select distinct shem from mechirot where ezor in 
	(select ezor from mechirot where shem = 'malka') 
	and shem != 'malka'



--  PART 2 - EXISTS
-- returns "yes" or "no" from subquery
-- NO need for LOGICAL CONNECTION between two parts of question!
-- �� ���� ����� ��� ������ ��� ��� ���� �������

-- select max(mechiraYomit) from mechirot


-- show rezerva mochrim eden (bad mocher...) is working
select * from rezerva 
where exists
(select * from mechirot where shem = 'eden')


-- show rezerva mochrim if highest sell was under 3500
select * from rezerva 
where exists
(select max(mechiraYomit) from mechirot having max(mechiraYomit) < 5000 )



--  PART 3 - ANY / ALL
-- show the reserva with higher then the highest - another way:
select * from rezerva where memuza > 
any
(select mechiraYomit from mechirot)
--���� ���� ������ �����


select * from rezerva where memuza > 
all
(select mechiraYomit from mechirot)
-- ���� ���� ����� �����


--  PART 4 - INTO

-- drop table totachim
create table totachim
( 
shem nvarchar(50)
)

insert into totachim
	select distinct shem from mechirot where mechiraYomit > 2500
select * from totachim



--  PART 5 - EXCEPT

select shem from mechirot 
except 
select shem from totachim


insert into totachim 
	select shem from mechirot where mechiraYomit > 
	(select avg(mechiraYomit) from mechirot)
select * from totachim



--  PART 6 - part of results

select * from mechirot 
-- select * from mechirot OFFSET (2) ROWS 
select * from mechirot order by siduri OFFSET (10) ROWS 
select * from mechirot order by siduri 
	OFFSET (10) ROWS FETCH NEXT (3) ROWS ONLY



