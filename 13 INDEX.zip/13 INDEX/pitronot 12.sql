
create table talm
(shem nvarchar(10),
mark int)

insert into talm values
('avi',88),
('sari',77),
('izik',66),
('tiki',82),
('kobi',22),
('miri',33),
('avital',44)

select * from talm

drop procedure tenfaktortrans
create procedure tenfaktortrans @odf int
as
begin
begin tran
update talm set mark = mark + @odf
declare @toomuch int
set @toomuch = (select count (*) from talm where mark > 100)
if @toomuch = 0
	begin
		commit tran
		select 'done'
	end
else
	begin
		rollback tran
		select 'rolled back...'
	end
end


select * from talm
exec tenfaktortrans @odf = 5
select * from talm
